#include <iostream>
#include <fstream>
#include <string>
#include <stdlib.h>
using namespace std;

struct Producto {
    string nombre;
    float precio;
};

struct Cliente {
    string nombre;
    Producto compras[100];
    int cantCompras;
    float totalGastado;

    Cliente() : cantCompras(0), totalGastado(0.0) {}
};

int leerDatos(const string& nombreArchivo, Producto productos[], int maxProductos);
void escribirDatos(const string& nombreArchivo, const Producto productos[], int cantidad);
void bubbleSort(Producto productos[], int cantidad);
void seleccionDirecta(Producto productos[], int cantidad);
void quickSortClientes(Cliente clientes[], int izquierda, int derecha);
int buscarProducto(const Producto productos[], int cantidad, const string& nombre);
void agregarProducto(Producto productos[], int& cantidad, const string& nombre, float precio);
void Menu();
void MenuCliente();
float calcularTotalVentas(const Cliente clientes[], int cantidad);
void mostrarTotalVentas(const Cliente clientes[], int cantidad);
void generarReporteVentasPorProducto(const Cliente clientes[], int cantClientes, const Producto productos[], int cantProductos);

void imprimirProducto(const Producto& producto) {
    int nombreWidth = 20; //cada palabra del producto tendra un ancho total de 20columnas
    cout<<producto.nombre;
    for(int i=producto.nombre.length(); i<nombreWidth; i++){
        cout<<' '; // Añade espacios hasta acompletar los 20
    }
    cout<<producto.precio<<endl;
}

int main(){
    int max_Productos = 100;
    Producto productos[max_Productos];
    int cantProductos = leerDatos("productos.txt", productos, max_Productos);	//el archivo se iguala a cantProductos

    if(cantProductos==0){
        cerr<<"No se leyeron datos del archivo" << endl;
        return 1;
    }

    int max_Clientes=100;
    Cliente clientes[max_Clientes];	//arreglo, usando el constructor->Cliente() : cantCompras(0), totalGastado(0.0) {}
    								//puede crear 100 objetos Cliente
    int cantClientes=0;			//evita datos basura
    int opcion;

    do {
        Menu();
        cout << "Seleccione una opcion: ";
        cin >> opcion;
        fflush(stdin);

        switch (opcion) {
            case 1: {
                if (cantClientes>=max_Clientes) {
                    cout<<"No se pueden agregar mas clientes." << endl;
                }else{
                    string nombreCliente;
                    cout<<"\nIngresa el nombre del cliente: ";
                    cin>>nombreCliente;
                    clientes[cantClientes].nombre = nombreCliente;	//guarda el nombre del cliente en el arreglo

                    int opcCliente;

                    cout << "\n";
                    system("pause");
                    system("cls");

                    do {
                        MenuCliente();
                        cout << "Seleccione una opcion: ";
                        cin >> opcCliente;
                        fflush(stdin);

                        switch (opcCliente) {
                            case 1: {
                                cout<<"\n************BIENVENIDO************"<<endl;
                                cout<<"Producto              Precio"<<endl;
                                for(int i=0; i<cantProductos; i++){	//llama al archivo y recorre cada fila
                                    imprimirProducto(productos[i]);
                                }

                                string nombreProducto;
                                cout<<"Ingrese el nombre del producto: ";
                                cin>>nombreProducto;

                                int productoIndex=buscarProducto(productos, cantProductos, nombreProducto);	//buscar producto e indice donde se encuentra

                                if (productoIndex==-1){	//valor fuera del rango del arreglo
                                    cout<<"Producto no encontrado"<<endl;
                                } else{
                                    Cliente& cliente = clientes[cantClientes];
                                    cliente.compras[cliente.cantCompras] = productos[productoIndex];	//agregar el producto
                                    cliente.totalGastado += productos[productoIndex].precio;	//suma cada que se agrega un producto
                                    cliente.cantCompras++;	//aumenta el contador
                                    cout << "Producto agregado al carrito exitosamente." << endl;
                                }
                                break;
                            }
                            
                            case 2: {
                                bubbleSort(productos, cantProductos);
                                break;
                            }
                            
                            case 3:{
                                seleccionDirecta(productos, cantProductos);

                                cout<<"Productos ordenados por precio de mayor a menor:"<<endl;
                                cout<<"\tUsando el metodo de Selección Directa."<<endl;
                                cout<<"Producto              Precio"<<endl;
                                for (int k=0; k<cantProductos; k++){
                                    imprimirProducto(productos[k]);
                                }
                                break;
                            }
                            
                            case 4:{
                                string nombreProducto;
                                cout<<"Ingrese el nombre del producto: ";
                                cin>>nombreProducto;

                                int productoIndex = buscarProducto(productos, cantProductos, nombreProducto);

                                if (productoIndex == -1) {
                                    cout << "Producto no encontrado." << endl;
                                } else {
                                    cout << "Producto encontrado: " << productos[productoIndex].nombre << " $" << productos[productoIndex].precio << endl;
                                }
                                break;
                            }
                            
                            case 5:
                                cout << "Regresando al menu principal." << endl;
                                break;
                                
                            default:
                                cout << "Opcion invalida." << endl;
                        }

                        cout << "\n";
                        system("pause");
                        system("cls");

                    }while(opcCliente!=5);

                    cantClientes++;
                    cout << "Cliente creado exitosamente." << endl;
                }
                break;
            }
            
            case 2:{
            	
                for(int i=0; i<cantClientes; i++){
                    cout<<"\n\n*******************SUPERMERCADO*****************"<<endl;
                    cout<<"__________________________________________________"<<endl;
                    cout<<"\tCliente: "<<clientes[i].nombre<<endl<<endl;
                    cout<<"\tCliente: Publico en general"<<endl<<endl;
                    cout<<"*************************************************"<<endl;
                    cout<<"Productos              Precio"<<endl;

                    for(int j=0; j<clientes[i].cantCompras; j++){
                        imprimirProducto(clientes[i].compras[j]);
                    }

                    cout<<"*******************************************************"<<endl;
                    cout<<"\n\t\t\tTotal Gastado: " << clientes[i].totalGastado <<endl;
                    cout<<"____________________________________________________"<<endl<<endl;
                }
                break;
            }
            
            case 3:{	// Ordenar clientes por total gastado METODO DE QUICKSORT
                Cliente clientesOrdenados[max_Clientes];

                for (int i=0; i<cantClientes; i++){
                    clientesOrdenados[i]=clientes[i];	//cada cliente ordeado se copea al arreglo clientes[i]
                }	

                quickSortClientes(clientesOrdenados, 0, cantClientes - 1);

                cout<<"\tClientes ordenados por total gastado."<<	endl;
                cout<<"CLIENTE                TOTAL GASTADO"<<endl;

                for(int i=0; i<cantClientes; i++){
                    cout<<clientesOrdenados[i].nombre;
                    
                    for(int j=clientesOrdenados[i].nombre.length(); j<20; j++){	//impresion de productos alineandolas
                        cout<<' ';
                    }
                    cout<<clientesOrdenados[i].totalGastado << endl;
                }

                mostrarTotalVentas(clientes, cantClientes);

                break;
            }
            case 4: {
                generarReporteVentasPorProducto(clientes, cantClientes, productos, cantProductos);
                break;
            }
            case 5: {
                cout << "Saliendo del programa." << endl;
                break;
            }
            default:
                cout << "Opcion invalida. Intente de nuevo." << endl;
        }

        cout << "\n";
        system("pause");
        system("cls");

    } while (opcion != 5);

    escribirDatos("productos.txt", productos, cantProductos);	//
    cout<<"Datos guardados. Saliendo del programa"<<endl;

    return 0;
}

int leerDatos(const string& nombreArchivo, Producto productos[], int maxProductos){
	
    ifstream archivo(nombreArchivo);	//abre el archivo .txt
    int contador=0;

    if(!archivo){
        cerr<<"Error al abrir el archivo "<<nombreArchivo<<endl;
        return 0;
    }

    while(archivo>>productos[contador].nombre>>productos[contador].precio){	//lee las lineas del archivo .txt y se van guardando el el arreglo productos
        //se ocupan >> ya que en cada iteracion del while esta leyendo dos valores (nombre del producto y precio)
        //para despues guardarlos en el arreglo productos
        //en la posicion "indicado o guiado" por el contador=0
        
		if (contador++>=maxProductos){	//conforme se va aumentado el contado, al mismo tiempo COMPARA
										//que no se exceda del maximo de nuestros productos
            break;
        }
    }

    archivo.close();	//cierra el archivo .txt
    return contador;
}

// Función para escribir datos en un archivo
void escribirDatos(const string& nombreArchivo, const Producto productos[], int cantidad){
	
    ofstream archivo(nombreArchivo);	//crea un archivo, pero si ya exite solo lo reescribe

    if (!archivo) {
        cerr<<"Error al abrir el archivo"<<nombreArchivo<<endl;
        return;
    }

    for (int i=0; i<cantidad; i++){	//se escribe lo del blog, nombre, espacio,precio
        archivo<<productos[i].nombre<<" "<<productos[i].precio<<endl;
    }

    archivo.close();
}

// Implementación de Bubble Sort (ineficiente)
void bubbleSort(Producto productos[], int cantidad){
	
    for (int i=0; i<cantidad; i++){	//cantidad de productos, controla el num."pasadas" que abra
        for (int j=0; j<cantidad-1; j++){	//comparara
            if (productos[j].precio > productos[j+1].precio){	//compara el precio del producto con el de la sig.posicion(j+1)
                Producto temp=productos[j];	//variable temporarl
                productos[j] = productos[j + 1];//mueve el producto (j+1) a la posicion j
                productos[j + 1]=temp;	//cambio completo de las variables	
            }
        }
    }

    cout << "\n\nProductos ordenados por precio de menor a mayor:" << endl;
    cout << "\tUsando el metodo Bubble Sort." << endl;
    cout << "Producto              Precio" << endl;
    for (int i = 0; i < cantidad; i++) {
        imprimirProducto(productos[i]);
    }
}

// Implementación de Selecccion Directa(eficiente), no en arreglos medianos o grandes, busca el mas pequeñp y lo posicion al inicio
void seleccionDirecta(Producto productos[], int cantidad){
	
    for (int i=0; i<cantidad-1; i++){
        int max=i;	//
        for (int j= i+ 1; j<cantidad; j++){	//busca el mayor que va de i hasta el final
            if (productos[j].precio > productos[max].precio){
                max=j;	//se actualiza , sera el nuevo indice con el mayor precio hasta el momento
            }
        }
        Producto temp = productos[max];	
        productos[max] = productos[i];	
        productos[i] = temp;	//intercambio final
    }
}

//Implementacion de Quickshort (eficiente)para arreglos grandes
void quickSortClientes(Cliente clientes[], int izquierda, int derecha){
    int i=izquierda, j=derecha;	//indices para recorrer el arreglo
    Cliente tmp;	//variable temporar donde intercambiara elementos del arreglos
    float pivot=clientes[(izquierda + derecha)/2].totalGastado;//pivote es el valor del totalGastado, que sera la posicion media del arreglo

    while (i<=j){	//hace la particion del arreglo
        while(clientes[i].totalGastado < pivot)	//avanza en el subarreglo
            i++;
        while (clientes[j].totalGastado > pivot)	//"atrasa"
            j--;
        if (i <= j){	//cumple la condicion
            tmp = clientes[i];	//se guarda en la posicion i
            clientes[i] = clientes[j];	
            clientes[j] = tmp;
            i++;	//se mueve el otro elemento
            j--;	//decrementa 
        }
    }	//hace la reparticion del arreglo

    if (izquierda < j)	//si se cumple, hay un subarreglo ala izquierda del pivote que debe ser ordenado
        quickSortClientes(clientes, izquierda, j);
    if (i < derecha) //hay un subarreglo ala derecha del pivote que debe ser ordenado
        quickSortClientes(clientes, i, derecha);
}

int buscarProducto(const Producto productos[], int cantidad, const string& nombre) {
    for (int i = 0; i < cantidad; i++) {
        if (productos[i].nombre == nombre) {
            return i;
        }
    }
    return -1;
}

void agregarProducto(Producto productos[], int& cantidad, const string& nombre, float precio) {
    productos[cantidad].nombre = nombre;
    productos[cantidad].precio = precio;
    cantidad++;
}

void Menu() {
    cout << "**********MENU PRINCIPAL**********" << endl;
    cout << "1. Registrar cliente" << endl;
    cout << "2. Mostrar clientes y sus compras" << endl;
    cout << "3. Ordenar clientes por total gastado(quicksort)" << endl;
    cout << "4. Reporte de ventas por producto" << endl;
    cout << "5. Salir" << endl;
}

void MenuCliente() {
    cout << "**********MENU CLIENTE**********" << endl;
    cout << "1. Agregar producto al carrito" << endl;
    cout << "2. Ordenar productos por precio (burbuja)" << endl;
    cout << "3. Ordenar productos por precio (seleccion directa)" << endl;
    cout << "4. Buscar producto" << endl;
    cout << "5. Regresar al menu principal" << endl;
}

float calcularTotalVentas(const Cliente clientes[], int cantidad) {
    float total=0;
    for (int i=0; i<cantidad; i++){
        total += clientes[i].totalGastado;
    }
    return total;
}

void mostrarTotalVentas(const Cliente clientes[], int cantidad){
    float totalVentas = calcularTotalVentas(clientes, cantidad);
    cout << "El total de ventas es: " << totalVentas << endl;
}

void generarReporteVentasPorProducto(const Cliente clientes[], int cantClientes, const Producto productos[], int cantProductos) {
    int ventasPorProducto[100] = {0};

    for (int i=0; i<cantClientes; i++){	//numero de clientes registrados
        for (int j=0; j<clientes[i].cantCompras; j++) {	//recorre las compras del clientes
            for (int k=0; k<cantProductos; k++){	//cantidad de productos
                if(clientes[i].compras[j].nombre == productos[k].nombre){//verifica que el producto sea igual al nombre del producto del arreglo
                    ventasPorProducto[k]++;	//aumenta el contador para el producto
                }	
            }
        }
    }

    cout << "Reporte de ventas por producto:" << endl;
    cout << "Producto              Ventas" << endl;
    
    for (int i=0; i<cantProductos; i++){	
        cout<<productos[i].nombre;
        
        for (int j = productos[i].nombre.length(); j <20; j++){
            cout << ' ';
        }
        cout<<ventasPorProducto[i]<<endl;//imprime el num.ventas del producto en la posición i del arreglo 
    }
}